#include <sys/types.h>
#include <sys/time.h>

/*
 * The usual:  Return the number of nanoseconds between 'now' and
 *             'prev'
 *
 * Copyright (C) 2002 David G. Andersen.  All rights reserved.
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENSE file that is distributed with this software.
 */

long timediff(const struct timeval *time_now,
	      const struct timeval *time_prev)
{
        long usecs_now;
        
        if (time_prev->tv_sec == 0 &&
            time_prev->tv_usec == 0) {
                return 0;
        }
        
        usecs_now = (time_now->tv_sec - time_prev->tv_sec) * 1000000;
        usecs_now += time_now->tv_usec;

        return usecs_now - time_prev->tv_usec;
}

