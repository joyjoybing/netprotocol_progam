/*
 * Routines to interface with pcap.  Don't go promiscuous.
 *
 * If you know the interface to use, pass it in as intf;  else, we'll
 * use the default pcap interface.
 *
 * Proto must be either 'tcp' or 'udp'
 *
 * If local_hostname specified, filter out non-local traffic.
 *
 * Copyright (C) 2002 David G. Andersen.  All rights reserved.
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENSE file that is distributed with this software.
 */

#include <pcap.h>
#include <net/bpf.h>
#include <stdio.h>
#include "debug.h"

pcap_t *setup_pcap(char *intf, char *proto, char *hostname, int srcport,
		   char *target)
{
    pcap_t *pcap = NULL;
    char *dev;
    char ebuf[PCAP_ERRBUF_SIZE];
    char progstr[256];

    int rc;
    
    bpf_u_int32 net, mask;

    struct bpf_program fp;

    DPRINTF(DEBUG_INIT, "pcap::setup_pcap starting\n");

    if (intf != NULL && intf[0] != '\0') {
	dev = intf;
    } else {
	dev = pcap_lookupdev(ebuf);
    }

    if (!dev) {
	DPRINTF(DEBUG_ERRS, "pcap::setup_pcap pcap_lookupdev failed: %s\n",
		ebuf);
	goto cleanup;
    }

    DPRINTF(DEBUG_INIT, "pcap::setup_pcap using dev %s\n", dev);
    
    if (pcap_lookupnet(dev, &net, &mask, ebuf) == -1) {
	DPRINTF(DEBUG_ERRS, "pcap::setup_pcap pcap_lookupnet failed: %s\n",
		ebuf);
	goto cleanup;
    }

    DPRINTF(DEBUG_INIT,
	    "pcap::setup_pcap net: 0x%lx mask 0x%lx hostname: %s\n",
	    (long)net, (long)mask,
	    (hostname ? hostname : "(none)"));

    /* ... length of data snarfed, not promiscuous, listen for 10ms ... */
    pcap = pcap_open_live(dev, 1024, 0, 10, ebuf);

    if (!pcap) {
	DPRINTF(DEBUG_ERRS, "pcap::setup_pcap pcap_open_live failed: %s\n",
		ebuf);
	goto cleanup;
    }

    snprintf(progstr, sizeof(progstr),
	     "%s %s%s %s%s",
	     proto,
	     hostname ? "and dst host " : "", /* If hostname, restrict */
	     hostname ? hostname : "",
	     target ? " and src host " : "",
	     target ? target : "");
    progstr[sizeof(progstr)-1] = 0;

    DPRINTF(DEBUG_INIT, "pcap::setup_pcap using filter %s\n", progstr);

    rc = pcap_compile(pcap, &fp, progstr, 1, mask);

    if (rc) {
	DEBUG_PERROR("pcap::setup_pcap pcap_compile failed");
	goto cleanup;
    }

    if (pcap_setfilter(pcap, &fp) == -1) {
	DEBUG_PERROR("pcap::setup_pcap pcap_setfilter failed");
	goto cleanup;
    }

    return pcap;

 cleanup:
    if (pcap) pcap_close(pcap);
    return NULL;

}

