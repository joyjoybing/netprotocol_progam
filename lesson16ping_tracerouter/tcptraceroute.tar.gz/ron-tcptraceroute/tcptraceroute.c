/*
 * hoplat:  Compute the round-trip latency and number of hops between
 *          two sites.  See README for more information.
 * 
 * Author:  David G. Andersen
 *
 * Copyright (C) 2002 David G. Andersen.  All rights reserved.
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENSE file that is distributed with this software.
 */

#include "config.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <ctype.h>
#include <pwd.h>
#include <grp.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/ioctl.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>
#include <netinet/ip_icmp.h>
#include <net/if.h>
#include <netdb.h>
#include <signal.h>

#include <net/bpf.h>
#include <pcap.h>

#ifdef __linux__
#define RON_PCAP_NO_TIMEOUT
#endif

#ifdef RON_PCAP_NO_TIMEOUT
/* This is SO broken it hurts.  Better to include or fix pcap later. */
struct fake_pcap_hdr {
    int fd;
    int snapshot;
};
#endif /* Broken linux pcap stuff */

/* Linux has redefined the structure names.  So, use our
 * own structure.. */

#ifndef tcp_seq
typedef u_int32_t tcp_seq;
#endif

struct my_tcphdr {
        u_short th_sport;               /* source port */
        u_short th_dport;               /* destination port */
        tcp_seq th_seq;                 /* sequence number */
        tcp_seq th_ack;                 /* acknowledgement number */
#if BYTE_ORDER == LITTLE_ENDIAN
        u_int   th_x2:4,                /* (unused) */
                th_off:4;               /* data offset */
#endif
#if BYTE_ORDER == BIG_ENDIAN
        u_int   th_off:4,               /* data offset */
                th_x2:4;                /* (unused) */
#endif
        u_char  th_flags;
        u_short th_win;                 /* window */
        u_short th_sum;                 /* checksum */
        u_short th_urp;                 /* urgent pointer */
};
#ifndef TH_FIN
#define TH_FIN  0x01
#endif
#ifndef TH_SYN
#define TH_SYN  0x02
#endif
#ifndef TH_RST
#define TH_RST  0x04
#endif
#ifndef TH_PUSH
#define TH_PUSH 0x08
#endif
#ifndef TH_ACK
#define TH_ACK  0x10
#endif


#ifdef HAVE_NET_ETHERNET_H	/* FreeBSD, Linux 2.x */
#include <net/ethernet.h>
#endif

#ifdef HAVE_NET_IF_ETHER_H	/* NetBSD 1.3 at least */
#include <net/if_ether.h>
#endif

#ifdef __FreeBSD__
#define RON_RAW_IP_NOT_RAW 1
#endif

#include "debug.h"
#include "ronlib.h"

/*
 * A few handy globals - our hostname and IP address
 */

#define MAX_INT_NAME_LEN 16

char hostname[256];
int g_srcport = 0;
struct in_addr hostip;
char g_intfname[MAX_INT_NAME_LEN+1];

int g_alldone = 0;
int g_gotone = 0;
int g_timeout = 3000000;  /* Microseconds for timeout */
int g_spacing = 1000000;  /* Microseconds between packets */
int g_outstanding = 0;
int g_perhost = 3;        /* How many probes per host */
int g_hopcount = 0;
int g_printed_main = 0;   /* XXX:  This is a stupid way to do this */

int g_probessent = 0;
int g_probesrecv = 0;
unsigned long long g_tottime = 0; /* XXX:  Susceptable to overflow */
int g_maxtime = 0, g_mintime = 0;

int ignore_dupes = 0;

int flags_fin = 0;
int flags_syn = 0;
int flags_ack = 0;

#define NUMPINGS 512 /* Number of outstanding pings we track */

struct pingsent {
    struct timeval timesent;
    u_int16_t srcport;
    u_int16_t dstport;
    u_int16_t ipid;
    int pingno;
    int dupes;
} pingtable[NUMPINGS];

int nextping;  /* Address in pingtable to use next */

void
usage()
{
    fprintf(stderr,
	    "usage:  tcptraceroute [-h] [-c count] [-i wait] \n"
	    "                      [-p dstport] [-P srcport] [-I iface] [-T ttl]\n"
            "                      [-FSA]\n"
	    "                      <host>\n"
	    );
}

void
help()
{
    usage();
    fprintf(stderr,
	    "      -h ...... help (this message)\n"
	    "      -p <port>....... use this remote TCP port\n"
	    "      -c # ........... send this many pings\n"
            "      -i <wait> ...... Delay this many seconds between pings\n"
	    "      -I <interface> . Use the specified interface\n"
	    "      -H <hostname> .. Specify my local hostname\n"
	    "      -F, -S, -A ..... Set FIN, SYN, or ACK flags, any combination\n"
#ifdef DEBUG
	    "      -d # ........... Debug level #\n"
#endif
	    );
}

void
sighandler(int whichsig)
{
    printf("Sighandler: %d\n", whichsig);
    g_alldone = 1;
}

/*
 * Fill in the 'hostname' and 'hostip' globals with some information
 * about ourself.
 */

void
localhostinfo()
{
    int rc;
    struct hostent *hp;

    if (hostname[0] == '\0') {	/* if not overridden by cmd. line */
	rc = gethostname(hostname, sizeof(hostname));
	if (rc == -1) {
	    perror("gethostname");
	    exit(-1);
	}
    }

    if (!inet_aton(hostname, &hostip)) {
	hp = gethostbyname(hostname);
	if (!hp) {
#ifdef HAS_HERROR
	    herror(hostname);
#else
	    fprintf(stderr, "could not resolve %s\n", hostname);
#endif
	    exit(-1);
	}
	bcopy(hp->h_addr_list[0], &hostip, hp->h_length);
    }
}

/*
 * Called by the libpcap dispatch function whenever we receive a packet.
 * Note that there's potentially a large delay between the packet actually
 * arriving and it getting here because libpcap buffers.  Therefore,
 * it's imperative to check the timestamp in the pcap_pktheader.
 */

void
gotpkt(u_char *ubuf, const struct pcap_pkthdr *hdr, const u_char *buffer)
{
    int pktlen;
    struct ip *ip;
    int iphl = 0;
    struct my_tcphdr *tcp;

    int srcport, dstport, i;

    int time_us;

    pktlen = hdr->len;
    if (pktlen < 44) {
	DPRINTF(DEBUG_ALL, "tcping: runt packet (%d bytes)\n", pktlen);
	return;
    }
    if (pktlen < 60) {
	/* XXX:  Assume it's a loopback.  This is a bad assumption. :) */
	DPRINTF(DEBUG_ALL, "tcping: non-ethernet packet (%d bytes)\n", pktlen);
	ip = (struct ip *)((char *)buffer + (pktlen-40));
    } else {
	ip = (struct ip *)(buffer + sizeof(struct ether_header));
    }
    
    DPRINTF(DEBUG_ALL, "Got a packet: %d bytes captured of %d\n", pktlen, hdr->len);
    
    iphl = ip->ip_hl << 2;
    tcp = (struct my_tcphdr *)((char *)ip + iphl);

    pktlen = ntohs(ip->ip_len);
    if (pktlen < 40) {
	DPRINTF(DEBUG_ALL, "tcping: runt packet (%d bytes)\n", pktlen);
	return;
    }

    if (ip->ip_p != IPPROTO_ICMP && ip->ip_p != IPPROTO_TCP) {
	DPRINTF(DEBUG_ALL, "tcping: non-TCP or ICMP packet\n");
	return;
    }

    if (ip->ip_p == IPPROTO_ICMP) {
	struct icmp *ic;
	struct ip *sent_ip;
	int sent_hlen;
	ic = (struct icmp *)((char *)ip + iphl);
	if (ic->icmp_type != ICMP_UNREACH &&
	    ic->icmp_type != ICMP_TIMXCEED) { return; }
	sent_ip = (struct ip *)(&ic->icmp_ip);
	sent_hlen = sent_ip->ip_hl << 2;
	tcp = (struct my_tcphdr *)((u_char *)sent_ip + sent_hlen);
	/* With the ICMP, we get it back as we sent it */
	dstport = ntohs(tcp->th_dport);
	srcport = ntohs(tcp->th_sport);
    } else {
	/* With TCP, it gets sent back to us reversed */
	dstport = ntohs(tcp->th_sport);
	srcport = ntohs(tcp->th_dport);
	g_alldone = 1;
    }

    for (i = 0; i < NUMPINGS; i++) {
	if (pingtable[i].srcport == srcport &&
	    pingtable[i].dstport == dstport) {
	    
	    pingtable[i].dupes++;
	    if (pingtable[i].dupes > 1 && ignore_dupes) {
		continue;
	    }
	    time_us = timediff(&hdr->ts, &pingtable[i].timesent);
	    if (g_printed_main) {
		printf("  %.3f ms", (float)time_us/1000);
	    } else {
		g_hopcount++;
		printf("\n%2d  %s  %.3f ms",
		       g_hopcount, inet_ntoa(ip->ip_src),
		       (float)time_us/1000);
		g_probesrecv++;
		g_outstanding--;
		g_printed_main = 1;
	    }
#if 0
	    printf("%d bytes from %s: tcping_seq=%d ttl=%d time=%.3f ms\n",
		   pktlen, inet_ntoa(ip->ip_src),
		   pingtable[i].pingno, ip->ip_ttl,
		   (float)time_us/1000);
#endif
	    g_tottime += time_us;
	    if (time_us < g_mintime || g_mintime == 0)
		g_mintime = time_us;
	    if (time_us > g_maxtime)
		g_maxtime = time_us;
	    g_gotone = 1;
	}
    }
    fflush(stdout);
    /* g_alldone = 1;*/
}

/*
 * Create a sane default state for an IPv4 packet
 */

void
init_ip(struct ip *ip)
{
    bzero(ip, sizeof(struct ip));
    ip->ip_v = 4;
    ip->ip_hl = sizeof(struct ip) >> 2;
    ip->ip_ttl =  64;
}

void
init_tcp(struct my_tcphdr *tcp)
{
    bzero(tcp, sizeof(struct my_tcphdr));
    tcp->th_win = htons(16384);
}

void
checksum_tcp(struct ip *ip, struct my_tcphdr *tcp)
{
    /* This could be made a lot faster, but doesn't need it */
    struct pseudo_header {           /* For TCP header checksum */
	unsigned int source_address;
	unsigned int dest_address;
	unsigned char placeholder;
	unsigned char protocol;
	unsigned short tcp_length;
	struct my_tcphdr tcp;
    } ph;

    ph.source_address = ip->ip_src.s_addr;
    ph.dest_address   = ip->ip_dst.s_addr;
    ph.placeholder    = 0;
    ph.protocol       = IPPROTO_TCP;
    ph.tcp_length     = htons(20);

    /* Setup TCP headers for checksum */

    bcopy((char *)tcp, (char *)&ph.tcp, 20);
	
    tcp->th_sum = in_cksum((unsigned short *)&ph, 32);
}

/* Send one ping to our target */
/* This is inefficient, but it works */

int
sendping(int rawsock, int srcport, int dstport, struct in_addr targetaddr,
	 int ipid, unsigned char ttl)
{
    char pktbuf[1500];
    
    struct ip *ip;
    struct my_tcphdr *tcp;
    struct sockaddr_in dst;

    int rc;
    int pktsize;

    bzero(pktbuf, sizeof(pktbuf));

    /* Set up the destination address */
    bzero(&dst, sizeof(dst));
#ifdef RON_HAS_STRUCT_SINLEN
    dst.sin_len = sizeof(dst);
#endif
    dst.sin_family = AF_INET;
    dst.sin_addr = targetaddr;

    ip = (struct ip *)pktbuf;
    tcp = (struct my_tcphdr *)(pktbuf + sizeof(struct ip));
    
    init_ip(ip);
    init_tcp(tcp);

    ip->ip_p = IPPROTO_TCP;
    ip->ip_id = htons(ipid);
    ip->ip_ttl = ttl;

    ip->ip_dst = dst.sin_addr;

    pktsize = sizeof(struct ip) + sizeof(struct my_tcphdr);
#ifdef RON_RAW_IP_NOT_RAW
    ip->ip_off = IP_DF;
    ip->ip_len = pktsize;
#else
    ip->ip_off = htons(IP_DF);
    ip->ip_len = htons(pktsize);
#endif

    ip->ip_src = hostip;

    if (!flags_syn && !flags_fin && !flags_ack) {
	/* Default to setting ACK */
	tcp->th_flags = TH_ACK;
    }
    else {
	if (flags_syn) tcp->th_flags |= TH_SYN;
	if (flags_fin) tcp->th_flags |= TH_FIN;
	if (flags_ack) tcp->th_flags |= TH_ACK;
    }
    tcp->th_sport = htons(srcport);
    tcp->th_dport = htons(dstport);
    tcp->th_seq = htonl(random());
    tcp->th_off = 5;
    tcp->th_ack = 0;
    checksum_tcp(ip, tcp);
    ip->ip_sum = in_cksum(pktbuf, sizeof( *ip));

    rc = sendto(rawsock, pktbuf, pktsize, 0,
		(struct sockaddr *)&dst, sizeof(dst));

    if (rc != pktsize) {
	perror("sendto failed");
	return -1;
    }
    return 0;
}

/* Return the number of microseconds it took, or -1 */
int
dotcping(pcap_t *pcap, int rawsock,
	 char *target, struct in_addr targetaddr,
	 int pingcount, int idstport)
{
    int srcport, dstport, ipid;
    struct timeval tv;
    long tleft; /* Timeout time left */
    int ttl = 1;
    int per_host_count = g_perhost;
    int ttlmax = 32;
    
    pingcount = ttlmax * g_perhost;

    srcport = random() % 5000 + 3000;
    
    while (!g_alldone) {
	if (pingcount != 0) {
	    srcport++;
	    if (srcport > 60000) {
		srcport = random() % 5000 + 3000;
	    }
	    if (idstport)
		dstport = idstport;
	    else
		dstport = random() % 5000 + 3000;
	    ipid = random() % 2048;
	    
	    if (per_host_count <= 0) {
		ttl++;
		per_host_count = g_perhost;
		g_printed_main = 0;
	    }
	    /* First, send a TCP packet out the raw socket */
	    if (sendping(rawsock, srcport, dstport, targetaddr, ipid, ttl)) {
		return -1;
	    }
	    //	    printf("Sent TTL %d number %d\n", ttl, per_host_count);fflush(stdout);
	    per_host_count--;
	    gettimeofday(&tv, NULL);

	    bzero(&pingtable[nextping], sizeof(struct pingsent));
	    pingtable[nextping].timesent = tv;
	    pingtable[nextping].srcport = srcport;
	    pingtable[nextping].dstport = dstport;
	    pingtable[nextping].ipid = ipid;
	    pingtable[nextping].pingno = g_probessent;
	    nextping++;
	    if (nextping >= NUMPINGS) nextping = 0;
	    if (pingcount > 0) pingcount--;
	    g_outstanding++;
	    g_probessent++;
	}
	
	if (g_alldone || (!g_outstanding && pingcount == 0)) {
	    return 0;
	}

	/* Now wait for either packet spacing time (if packets remaining)
	 * or timeout (if no packets and just waiting for timeout)
	 */
	if (pingcount != 0)
	    tleft = g_spacing;
	else
	    tleft = g_timeout;

	while (tleft > 0) {
	    struct timeval tstart, tend;
	    /* Next, dispatch to pcap to retrieve it */
	    gettimeofday(&tstart, NULL);
	    /* Linux's pcap_dispatch is broken and ignores the timeout */
#ifdef RON_PCAP_NO_TIMEOUT
	    {
		struct timeval tout;
		fd_set readfds;
		struct fake_pcap_hdr *h;
		
		h = (struct fake_pcap_hdr *)pcap;

		FD_ZERO(&readfds);
		FD_SET(h->fd, &readfds);
		tout.tv_sec = 0;
		tout.tv_usec = tleft;
		if (select(h->fd+1, &readfds, NULL, NULL, &tout) == 1) {
		    pcap_dispatch(pcap, -1, gotpkt, NULL);
		}
	    }
#else
	    pcap_dispatch(pcap, -1, gotpkt, NULL);
#endif
	    if (g_gotone) {
		g_gotone = 0;
		tleft = 0;
	    }
	    else {
		gettimeofday(&tend, NULL);
		tleft -= timediff(&tend, &tstart);
	    }

	    if (g_alldone || (!g_outstanding && pingcount == 0)) return 0;
	}
	if (pingcount == 0) return 0;  /* We've timed out */
    }
    return 0;

}

int
resolve(char *host, struct in_addr *addr)
{
    struct hostent *he;

    if (!inet_aton(host, addr)) {
        he = gethostbyname(host);
        if (!he) { return -1; }
        memcpy(addr, he->h_addr, he->h_length);
    }
    return 0;
}

pcap_t *setup_pcap2(char *intf, char *hostname, int srcport,
		   char *target)
{
    pcap_t *pcap = NULL;
    char *dev;
    char ebuf[PCAP_ERRBUF_SIZE];
    char progstr[256];

    int rc;
    
    bpf_u_int32 net, mask;

    struct bpf_program fp;

    DPRINTF(DEBUG_INIT, "pcap::setup_pcap starting\n");

    if (intf != NULL && intf[0] != '\0') {
	dev = intf;
    } else {
	dev = pcap_lookupdev(ebuf);
    }

    if (!dev) {
	DPRINTF(DEBUG_ERRS, "pcap::setup_pcap pcap_lookupdev failed: %s\n",
		ebuf);
	goto cleanup;
    }

    DPRINTF(DEBUG_INIT, "pcap::setup_pcap using dev %s\n", dev);
    
    if (pcap_lookupnet(dev, &net, &mask, ebuf) == -1) {
	DPRINTF(DEBUG_ERRS, "pcap::setup_pcap pcap_lookupnet failed: %s\n",
		ebuf);
	goto cleanup;
    }

    DPRINTF(DEBUG_INIT,
	    "pcap::setup_pcap net: 0x%lx mask 0x%lx hostname: %s\n",
	    (long)net, (long)mask,
	    (hostname ? hostname : "(none)"));

    /* ... length of data snarfed, not promiscuous, listen for 10ms ... */
    pcap = pcap_open_live(dev, 1024, 0, 10, ebuf);

    if (!pcap) {
	DPRINTF(DEBUG_ERRS, "pcap::setup_pcap pcap_open_live failed: %s\n",
		ebuf);
	goto cleanup;
    }

    snprintf(progstr, sizeof(progstr),
	     "(%s %s%s %s%s) or icmp",
	     "tcp",
	     hostname ? "and dst host " : "", /* If hostname, restrict */
	     hostname ? hostname : "",
	     target ? " and src host " : "",
	     target ? target : "");
    progstr[sizeof(progstr)-1] = 0;

    DPRINTF(DEBUG_INIT, "pcap::setup_pcap using filter %s\n", progstr);

    rc = pcap_compile(pcap, &fp, progstr, 1, mask);

    if (rc) {
	DEBUG_PERROR("pcap::setup_pcap pcap_compile failed");
	goto cleanup;
    }

    if (pcap_setfilter(pcap, &fp) == -1) {
	DEBUG_PERROR("pcap::setup_pcap pcap_setfilter failed");
	goto cleanup;
    }

    return pcap;

 cleanup:
    if (pcap) pcap_close(pcap);
    return NULL;

}


int
main(int argc, char **argv)
{
    extern char *optarg;
    extern int optind;
    int ch;
    char *target;
    int dstport = 0;

    struct in_addr targetaddr;
    
    int pingcount = -1;  /* Go forever */
    int semi_secure = 0;     /* Change to a different UID after startup */
    /* (We use nobody / nogroup ) */
    pcap_t *pcap = NULL;
    int rawsock = -1;

    memset(g_intfname, '\0', sizeof(g_intfname));
    memset(hostname, '\0', sizeof(hostname));
    
    while ((ch = getopt(argc, argv, "d:i:c:shp:P:f:n:I:H:NFSAD")) != -1)
	switch (ch) {
	case 'c':
	    if (optarg[0] != 0 && isdigit(optarg[0])) {
		pingcount = atoi(optarg);
		if (pingcount < 1) {
		    fprintf(stderr, "tcping::main probes must be positive\n");
		    exit(-1);
		}
	    } else {
		fprintf(stderr, "tcping::main bad pingcount %s\n", optarg);
		exit(-1);
	    }
	    break;
	case 'D':
	    ignore_dupes = 1;
	    break;
	case 'H':
	    strncpy(hostname, optarg, sizeof(hostname));
	    hostname[sizeof(hostname)-1] = '\0';
	    break;
	case 'I':
	    strncpy(g_intfname, optarg, MAX_INT_NAME_LEN);
	    g_intfname[MAX_INT_NAME_LEN] = '\0';
	    break;
	case 'd':
	    set_debug(optarg);
	    break;
	case 'h':
	    help();
	    exit(0);
	case 's':
	    semi_secure = 1;
	    break;
	case 'p':
	    if (optarg && optarg[0] && isdigit(optarg[0])) {
		dstport = atoi(optarg);
	    } else {
		usage();
		exit(-1);
	    }
	    break;
	case 'i':
	    if (optarg && optarg[0] && isdigit(optarg[0])) {
		g_spacing = atoi(optarg) * 1000000;
	    } else {
		usage();
		exit(-1);
	    }
	    break;
	case 'F':
	    flags_fin = 1;
	    break;
	case 'S':
	    flags_syn = 1;
	    break;
	case 'A':
	    flags_ack = 1;
	    break;
	default:
	    usage();
	    exit(-1);
	}
    argc -= optind;
    argv += optind;

    if (argc < 1) {
	usage();
	exit(-1);
    }

    target = argv[0];

    if (resolve(target, &targetaddr)) {
	herror(target);
	exit(-1);
    }

    localhostinfo();		/* Set globals */

    signal(SIGINT, sighandler);

    srandom(time(NULL) + getpid());

    rawsock = raw_socket();
    if (rawsock == -1) {
	perror("tcping::main could not create raw socket");
	exit(-1);
    }

    /* Try to ensure that we don't get blocked before sending */
    setpriority(PRIO_PROCESS, 0, -10);

    pcap = setup_pcap2(g_intfname, hostname, 0, target);

    if (pcap == NULL) {
	perror("tcping::main could not allocate pcap");
	exit(-1);
    }


    /*
     * For setuid operation, we should switch back to the UID
     * of the invoking user before we do anything else.  This
     * isn't a total guarantee of security, but it helps a wee bit.
     */
    
    if (geteuid() == 0 &&
	getuid != 0) {
	if (setgid(getgid()))  { perror("setgid"); exit(-1); }
	if (setgid(getgid()))  { perror("setegid"); exit(-1); }
	if (setuid(getuid()))  { perror("setuid"); exit(-1); }
	if (seteuid(getuid())) { perror("seteuid"); exit(-1); }
    } else if (getuid == 0) {
	/* We're being run by root.  If semi-secure, then
	 * switch to 'nobody'.  An attempt to prevent the spread
	 * of compromise if anything bad happens.
	 */
	if (semi_secure) {
	    struct passwd *pwd;
	    struct group *grp;
	    
	    pwd = getpwnam("nobody");
	    if (!pwd) {
		perror("tcping::main semi-secure: no pw entry for nobody");
		exit(-1);
	    }
	    
	    grp = getgrnam("nogroup");
	    if (!grp) {
		grp = getgrnam("nobody");
		if (!grp) {
		    perror("tcping::main semi-secure: no group for nogroup");
		    exit(-1);
		}
	    }
	    
	    if (setgid(grp->gr_gid)) {
		perror("tcping::main setgid"); exit(-1);
	    }
	    if (setegid(grp->gr_gid)) {
		perror("tcping::main setegid"); exit(-1);
	    }
	    if (setuid(pwd->pw_uid)) {
		perror("tcping::main setuid"); exit(-1);
	    }
	    if (seteuid(pwd->pw_uid)) {
		perror("tcping::main seteuid"); exit(-1);
	    }
	}
    } /* Otherwise, the user is running it as themselves.  Let 'em try. */

    printf("traceroute to %s (%s), some hops max, some byte packets\n",
	   target, inet_ntoa(targetaddr));
    
    dotcping(pcap, rawsock, target, targetaddr, pingcount, dstport);
    pcap_close(pcap);
    printf("\n");
#if 0
    printf("--- %s tcping statistics ---\n", target);
    if (g_probessent > 0) {
        printf("%d packets transmitted, %d packets received, %d%% packet loss\n",
    	       g_probessent, g_probesrecv,
	       (int)((g_probessent - g_probesrecv) * 100) / g_probessent);
    }
    if (g_probesrecv > 0)
	printf("round-trip min/avg/max = %.3f/%.3f/%.3f ms\n",
	       (float)g_mintime/1000,
	       /*XXX*/(float)(g_tottime/g_probesrecv)/1000.0,
	       (float)g_maxtime/1000);
#endif
    exit(0);
}
