/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/*
 * Do we have a sin_len in struct sockaddr_in?
 */
#undef RON_HAS_STRUCT_SINLEN

/*
 * Do we have the 4.4BSD daemon() call?
 */
#undef HAVE_DAEMON_SYSCALL

/*
 * Can we execute traceroute?
 */
#undef RON_HAS_TRACEROUTE

/*
 * Can we execute ttcp?
 */
#undef RON_HAS_TTCP

/* Define if you have the MD5Init function.  */
#undef HAVE_MD5INIT

/* Define if you have the gethostbyname function.  */
#undef HAVE_GETHOSTBYNAME

/* Define if you have the socket function.  */
#undef HAVE_SOCKET

/* Define if you have the <net/ethernet.h> header file.  */
#undef HAVE_NET_ETHERNET_H

/* Define if you have the <net/if_ether.h> header file.  */
#undef HAVE_NET_IF_ETHER_H

/* Define if you have the <pcap/net/bpf.h> header file.  */
#undef HAVE_PCAP_NET_BPF_H

/* Define if you have the <net/ip_compat.h> header file.  */
#undef HAVE_NET_IP_COMPAT_H

/* If FreeBSD.  Is this strictly necessary?  Needs to be changed! */
#undef FREEBSD

/* If Gnu/Linux .. again, this should not be in here, but need
 * to get things building with the ns commit.. */
#undef GNU_LINUX
