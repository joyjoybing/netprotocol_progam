/*
 * Rather boring.  Define the debugging stuff.
 *
 * Copyright (C) 2002 David G. Andersen.  All rights reserved.
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENSE file that is distributed with this software.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "debug.h"

unsigned int debug = 0;

/* We could autogenerate this if we felt like it */

struct debug_def {
    int debug_val;
    char *debug_def;
};

static
struct debug_def debugs[] = {
#include "debug-text.h"
#if 0
    { 0, "No debugging"},
    { 1, "Verbose error reporting"},
    { 2, "Debug initialization"},
    { 4, "Debug requests"},
#endif
    { 0, NULL } /* End of list marker */
};

int set_debug(char *arg)
{
    int i;
    if (!arg || arg[0] == '\0') {
	return -1;
    }

    if (arg[0] == '?' || !strcmp(arg, "list")) {
	fprintf(stderr,
		"Debug values and definitions\n"
		"----------------------------\n");
	for (i = 0;  debugs[i].debug_def != NULL; i++) {
	    fprintf(stderr, "%5d  %s\n", debugs[i].debug_val,
		    debugs[i].debug_def);
	}
	return -1;
    }

    if (isdigit(arg[0])) {
	debug |= atoi(arg);
    }
    return 0;
}


void IPDUMP(struct ip *ip) {
    fprintf(stderr,
            "IP dump:\n"
            "  version:  %d\n"
            "  HL:       %d\n"
            "  TOS:      %d\n"
            "  LEN:      %d\n"
            "  ID:       %d\n"
            "  Offset:   %d\n"
            "  Protocol: %d\n"
            "  Checksum: %d\n"
            "  TTL:      %d\n"
            "  Src:      %s\n",
            ip->ip_v,
            ip->ip_hl,
            ip->ip_tos,
            ntohs(ip->ip_len),
            ntohs(ip->ip_id),
            ntohs(ip->ip_off),
            ip->ip_p,
            ntohs(ip->ip_sum),
            ip->ip_ttl,
            inet_ntoa(ip->ip_src));
    fprintf(stderr,
            "  Dst:      %s\n",
            inet_ntoa(ip->ip_dst));
}

#ifdef _TEST_DEBUG_
int main() {
    if (set_debug("?") != -1) {
	fprintf(stderr, "set_debug(\"?\") returned wrong result code\n");
    }
    exit(0);
}
#endif	

