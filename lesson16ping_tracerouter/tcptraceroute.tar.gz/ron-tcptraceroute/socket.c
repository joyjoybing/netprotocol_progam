/*
 * Some convenient routines for handling sockets.
 *
 * Copyright (C) 2002 David G. Andersen.  All rights reserved.
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENSE file that is distributed with this software.
 * 
 * The routine "in_cksum" is Copyright (c) 1988, 1992, 1993
 *      The Regents of the University of California.  All rights reserved.
 * Regarding this routine:
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by the University of
 *      California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * (phew, you borrow one little checksum routine, and look what it comes with?)
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <netdb.h>

#include "debug.h"
#include "config.h"
#ifdef DMALLOC
#include <dmalloc.h>
#endif

int bound_udp_socket(short port)
{
    int sock;
    struct sockaddr_in saddr;

    sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock == -1) {
	DEBUG_PERROR("socket::bound_udp_socket socket call");
	return -1;
    }

    bzero(&saddr, sizeof(saddr));
#ifdef RON_HAS_STRUCT_SINLEN
    saddr.sin_len = sizeof(saddr);
#endif
    saddr.sin_port = htons(port);
    saddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sock, (struct sockaddr *)&saddr, sizeof(saddr)) == -1) {
	DEBUG_PERROR("socket::bound_udp_socket bind call");
	return -1;
    }
    return sock;
}

int raw_socket() {
    int sock;
    int on = 1;

    sock = socket(PF_INET, SOCK_RAW, IPPROTO_RAW);
    if (sock == -1) {
	DEBUG_PERROR("socket::raw_socket socket raw create failed");
	return -1;
    }

    if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &on, sizeof(on)) < 0) {
	DEBUG_PERROR("socket::raw_socket setsockopt HDRINCL failed");
	return -1;
    }
    return sock;
}

/*
 * in_cksum --
 *	Checksum routine for Internet Protocol family headers (C Version)
 *      From FreeBSD's ping.c
 *  ... not sure if this really belongs in socket.c, but what the heck. :)
 */

u_short
in_cksum(u_short *addr, int len)
{
	register int nleft = len;
	register u_short *w = addr;
	register int sum = 0;
	u_short answer = 0;

	/*
	 * Our algorithm is simple, using a 32 bit accumulator (sum), we add
	 * sequential 16 bit words to it, and at the end, fold back all the
	 * carry bits from the top 16 bits into the lower 16 bits.
	 */
	while (nleft > 1)  {
		sum += *w++;
		nleft -= 2;
	}

	/* mop up an odd byte, if necessary */
	if (nleft == 1) {
		*(u_char *)(&answer) = *(u_char *)w ;
		sum += answer;
	}

	/* add back carry outs from top 16 bits to low 16 bits */
	sum = (sum >> 16) + (sum & 0xffff);	/* add hi 16 to low 16 */
	sum += (sum >> 16);			/* add carry */
	answer = ~sum;				/* truncate to 16 bits */
	return(answer);
}

/*
 * Laziness is good.  Take an in_addr and fill in a hostname
 */

void
iptoname(struct in_addr *inaddr, char *hostname, int namelen)
{
    struct hostent *he;

    he = gethostbyaddr((char *)inaddr, sizeof(*inaddr), AF_INET);
    if (!he) {
	strncpy(hostname, inet_ntoa(*inaddr), namelen);
    } else {
	strncpy(hostname, he->h_name, namelen);
    }
}

/*
 * Same idea.  Convert a hostname to an inaddr
 */

int
nametoip(char *hostname, struct in_addr *inaddr)
{
    struct hostent *hp;

    if (!inet_aton(hostname, inaddr)) {
	hp = gethostbyname(hostname);
	if (!hp) {
	    /* Both tries at resolving failed... */
	    return -1;
	}

	bcopy(hp->h_addr_list[0], inaddr, hp->h_length);
    }
    return 0;
}

