#ifndef _RONLIB_H_
#define _RONLIB_H_
/*
 * Some handy routines used throughout RON
 *
 * Copyright (C) 2002 David G. Andersen.  All rights reserved.
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENSE file that is distributed with this software.
 */

#ifdef __cplusplus
extern "C" {
#endif
/* Create a locally (INADDR_ANY) bound UDP socket */
int bound_udp_socket(short port);

/* Create a raw socket with the IP_HDRINCL flag set on it */
int raw_socket();

/* Name resolution handy routines */
void iptoname(struct in_addr *inaddr, char *hostname, int namelen);
int nametoip(char *hostname, struct in_addr *inaddr);

/* The internet checksum function */
u_short in_cksum(u_short *addr, int len);

/* My favorite time manipulation routine */
/* Returns microseconds;  assumes diff is < max_long */
long timediff(const struct timeval *time_now, const struct timeval *time_prev);

#ifdef __cplusplus
}
#endif

#endif /* _RONLIB_H_ */
